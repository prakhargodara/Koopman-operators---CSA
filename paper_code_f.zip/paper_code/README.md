# Beyond DSA: Conjugacy-based Comparison of Dynamical Systems — code

This repository contains the code used to produce all figures in the paper
**"Beyond DSA: Conjugacy-based Comparison of Dynamical Systems"** by
Prakhar Godara, Pang Shiang Tay, and Marcelo G. Mattar.

The code accompanies two empirical studies and three appendix analyses:

- **Section 5.1 (EDMD pipeline).** Pairs of logistic-map systems are
  compared after either a state-space conjugacy or a change of observable
  dictionary (Fourier ↔ Legendre). Implements DSA (orthogonal alignment)
  and CSA (alignment by a parametric bijection family).
- **Section 5.2 (Hankel-DMD / Krylov pipeline).** Pairs of contracting
  linear maps are conjugated by a smooth two-parameter bijection family;
  Koopman matrices are fitted from delay-embedded scalar trajectories.
  Implements DSA-Krylov and CSA-Krylov.
- **Appendices.** Operator convergence in dictionary size / SVD rank,
  robustness of CSA to misspecification of the bijection class, and
  robustness to finite data and measurement noise.

In the code, CSA is also called **CCD** (conjugacy-constrained distance);
file and variable names such as `ccd_v2.py` or `ccd_distances_*.npy`
refer to CSA.

---

## Repository layout

```
paper_code/
├── edmd/                        # Section 5.1 — EDMD experiments
│   ├── bases_v2.py              # Fourier / shifted-Legendre dictionaries on [0,1]
│   ├── bijections.py            # h_θ(x) = x + θ sin(πx) on [0,1]
│   ├── koopman_v2.py            # EDMD: Φ(f(x)) ≈ K Φ(x)
│   ├── dsa.py                   # DSA: min_{Q ∈ O(m)} ‖K₁ − Q K₂ Qᵀ‖_F
│   ├── ccd_v2.py                # CSA: min_θ ‖P_θ K₁ − K₂ P_θ‖_F / ‖P_θ‖_F
│   │
│   ├── main.py                  # Within-/cross-basis distance matrices
│   │                            #   → Results/{dsa,ccd}_distances_{fourier,legendre,cross_*}.npy
│   │                            #     k_values.npy
│   ├── state_transform_no_basis_change_theta_sweep.py
│   │                            # State-space conjugacy sweep (θ on h_θ); same operators
│   │                            # and CSA routine as main.py, so Fig. 1 is its θ = 0.10 slice
│   │                            #   → StateTransformNoBasisChangeResults/*.npy
│   ├── basis_change_robustness.py
│   │                            # Grassmannian sweep between Fourier and Legendre
│   │                            #   → PureBasisChangeResults/*.npy
│   ├── paper_edmd_figures.py    # Renders all EDMD figures from the npy files above
│   │                            #   → plots/*.{pdf,png}
│   ├── Results/                                  (generated)
│   ├── StateTransformNoBasisChangeResults/       (generated)
│   ├── PureBasisChangeResults/                   (generated)
│   └── plots/                                    (generated)
│
├── krylov/                      # Section 5.2 — Hankel-DMD / Krylov experiments
│   ├── maps.py                  # 1-D iterated maps; trajectory generation
│   ├── krylov_subspace.py       # Delay matrix, SVD truncation
│   ├── koopman_delay.py         # Fit K in SVD-truncated delay coordinates
│   ├── dsa_original.py          # DSA-Krylov (orthogonal alignment)
│   ├── csa_krylov.py            # CSA-Krylov (parametric basis-transfer P_θ)
│   │
│   ├── paper_section3_smooth_afreq.py
│   │                            # Smooth two-parameter family h_{a,n};
│   │                            # rank, n, and a sweeps
│   │                            #   → Results/section3_smooth_{rank,n,a_freq}_sweep.npz
│   ├── plot_section3_smooth_distances.py
│   │                            # Renders Figure 5 panels
│   │                            #   → plots/smooth_bijection_{deviation,*sweeps,rank_sweep}.{pdf,png}
│   ├── Results/                                  (generated)
│   └── plots/                                    (generated)
│
├── convergence/                 # Appendix — operator convergence (Figure 7)
│   ├── conv_grid_edmd.py        # ρ_x(k, n_basis, basis) for the EDMD operators
│   │                            #   → Results/conv_grid_edmd.npz
│   ├── conv_rank_smooth.py      # ρ_x(rank) for the four Hankel-DMD systems, with the
│   │                            # data and fit of Fig. 5c (imports krylov/)
│   │                            #   → Results/conv_rank_smooth.npz
│   ├── plot_appendix.py         # → plots/appendix_residual.pdf
│   ├── Results/                                  (generated)
│   └── plots/                                    (generated)
│
├── misspecification/            # Appendix — misspecified bijection class (Figure 8)
│   ├── theta_landscape.py       # J(h_θ) landscape at θ* = 0.10 and capped-domain sweep
│   │                            #   → Results/theta_landscape.npz
│   ├── plot_theta_landscape.py  # → plots/appendix_theta_landscape.pdf
│   ├── Results/                                  (generated)
│   └── plots/                                    (generated)
│
├── noise/                       # Appendix — finite data × measurement noise (Figure 9)
│   ├── noise_robustness.py      # N × σ factorial sweep, 5 replicates
│   │                            #   → Results/noise_robustness.npz
│   ├── plot_noise_robustness.py # → plots/appendix_noise_robustness.pdf (+ summary table)
│   ├── Results/                                  (generated)
│   └── plots/                                    (generated)
│
├── make_paper_figures.py        # Assembles all paper figures → figures/
├── figures/                                      (generated)
├── requirements.txt
├── .gitignore
└── README.md
```

The shipped repository contains the precomputed `Results/`, `plots/` and
`figures/` directories so figures can be regenerated without rerunning the
full sweeps.

---

## Installation

The code requires **Python 3.10+** and three scientific libraries:

```
numpy
scipy
matplotlib
```

A minimal setup with `venv`:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Tested with Python 3.12.3, numpy 1.26.4, scipy 1.16.1 and matplotlib 3.6.3.

Assembling the multi-panel figures (`make_paper_figures.py`) additionally
uses `pdflatex` with the `standalone` class (any standard TeX Live
installation); without it, the individual panels are still produced.

---

## Reproducing the paper figures

Each subdirectory is self-contained: scripts use `os.path.dirname(__file__)`
to resolve their own `Results/` and `plots/` folders, so you can run them
from anywhere. Data-generating scripts are slow (minutes to tens of
minutes; `krylov/paper_section3_smooth_afreq.py` takes about 7 minutes
per sweep, and `python3 krylov/paper_section3_smooth_afreq.py rank|n|a`
runs a single sweep);
plotting scripts only read the saved results.

### Figures 1, 3 and 6 — fixed-basis, cross-basis and within-basis distance matrices

```bash
python3 edmd/main.py                    # populates edmd/Results/
python3 edmd/paper_edmd_figures.py      # renders edmd/plots/
```

### Figure 2 — robustness to state-space transformations

```bash
python3 edmd/state_transform_no_basis_change_theta_sweep.py   # populates StateTransformNoBasisChangeResults/
python3 edmd/paper_edmd_figures.py
```

The sweep builds its operators from the same samples, dictionary and ridge
as `main.py` and uses the same CSA routine, on the grid θ = 0, 0.02, …, 0.30;
its θ = 0.10 slice is exactly the data of Figure 1. Panel (c) reports the
recovered θ̂ on the ten conjugate pairs (mean ± s.d. over k). The θ values
are processed in parallel (`concurrent.futures`).

### Figure 4 — robustness to basis mismatch

```bash
python3 edmd/basis_change_robustness.py   # populates PureBasisChangeResults/
python3 edmd/paper_edmd_figures.py
```

### Figure 5 — Hankel-DMD / Krylov comparison

```bash
python3 krylov/paper_section3_smooth_afreq.py       # rank/n/a sweeps; populates krylov/Results/
python3 krylov/plot_section3_smooth_distances.py
```

### Figure 7 — operator convergence

```bash
python3 convergence/conv_grid_edmd.py     # ρ_x for Fourier/Legendre EDMD across k and n_basis
python3 convergence/conv_rank_smooth.py   # ρ_x for Hankel-DMD across SVD rank (Fig. 5c data and fit)
python3 convergence/plot_appendix.py
```

### Figure 8 — misspecification of the bijection class

```bash
python3 misspecification/theta_landscape.py
python3 misspecification/plot_theta_landscape.py
```

### Figure 9 — robustness to measurement noise

```bash
python3 noise/noise_robustness.py
python3 noise/plot_noise_robustness.py     # also prints the summary table
```

### Assembling the figures as included in the manuscript

```bash
python3 make_paper_figures.py              # → figures/Fig1.pdf … Fig5.pdf, app1.pdf, appendix_*.pdf
```

---

## Map of paper figures → output files

| Paper figure | File in `figures/` | Panels (in the `plots/` folders) | Producing script |
| --- | --- | --- | --- |
| Fig. 1 | `Fig1.pdf` | `fixed_basis_transform_heatmap_{ccd,dsa}`, `fixed_basis_scatter_{ccd,dsa}` | `edmd/paper_edmd_figures.py` |
| Fig. 2 | `Fig2.pdf` | `state_transform_{nrmse,pearson,recovered_theta}` | `edmd/paper_edmd_figures.py` |
| Fig. 3 | `Fig3.pdf` | `cross_basis_heatmap_{ccd,dsa}`, `cross_basis_scatter_{ccd,dsa}` | `edmd/paper_edmd_figures.py` |
| Fig. 4 | `Fig4.pdf` | `basis_change_{nrmse,pearson}` | `edmd/paper_edmd_figures.py` |
| Fig. 5 | `Fig5.pdf` | `smooth_bijection_{deviation,n_and_a_sweeps,rank_sweep}` | `krylov/plot_section3_smooth_distances.py` |
| Fig. 6 | `app1.pdf` | `within_basis_8_heatmaps_rowwise` | `edmd/paper_edmd_figures.py` |
| Fig. 7 | `appendix_residual.pdf` | `appendix_residual` | `convergence/plot_appendix.py` |
| Fig. 8 | `appendix_theta_landscape.pdf` | `appendix_theta_landscape` | `misspecification/plot_theta_landscape.py` |
| Fig. 9 | `appendix_noise_robustness.pdf` | `appendix_noise_robustness` | `noise/plot_noise_robustness.py` |

---

## Implementation notes

- **DSA** is implemented as Riemannian steepest descent on `O(m)` with
  Barzilai–Borwein step sizes, polar retraction, Schur-based spectral
  initialisation, and restarts on both connected components of the
  orthogonal group. Two copies live in the repo
  (`edmd/dsa.py`, `krylov/dsa_original.py`) because each subpackage
  is self-contained.
- **CSA / CCD** follows Algorithm 1 of the paper: a coarse θ-grid search
  followed by bounded `scipy.optimize.minimize_scalar` (Brent) refinement
  around the best candidates (`edmd/ccd_v2.py`, used for Figs. 1, 2, 3
  and 6: 121-point grid on |θ| ≤ 0.31, top-5 refinements in a ±0.02
  window; the appendix analyses of Figs. 8 and 9: 621-point grid, one
  refinement in a ±0.002 window). In the
  basis sweep of Fig. 4 the bijection is the identity, so `P` is computed
  directly without a θ search. The Krylov variant
  (`krylov/csa_krylov.py:compute_csa_krylov_distance`)
  generalises this to arbitrary parametric families; for the family
  h_{a,n} of Fig. 5 it searches, for each integer n ∈ {0, …, 10} (n = 0
  is the identity), a 19-point grid in a ∈ [0, 0.95] with Brent refinement
  (±1.5 grid steps) around the top-30 candidates, and reports the minimum
  over n. For Fig. 5 it is evaluated as `d(K_g, K_f)`, twin first: the
  twin is built as `g = h⁻¹ ∘ f ∘ h`, so `h ∘ g = f ∘ h` and the family
  member h_{a,n} itself is the conjugacy (`P_θ` regresses
  `φ_f(h_θ(x))` on `φ_g(x)`; the linear map's Krylov dictionary spans
  only {1, x}).
- **Krylov coordinates (Fig. 5).** DSA-Krylov and CSA-Krylov compare the
  same Koopman matrices (`krylov/paper_section3_smooth_afreq.py:fit_at_rank`).
  Each system uses the first `r' = min(r, #{k : σ_k > 10⁻⁸ σ_1})` SVD
  directions of its own Hankel matrix, scaled by `1/σ_k`
  (`φ = Σ⁻¹ V_{r'}ᵀ z`). These are the eigen-time-delay coordinates of the
  original DSA package (its `A_v`) and are orthonormal over the training
  data; K is fitted in them. The two matrices of a pair can differ in
  size; DSA zero-pads the smaller one (`krylov/dsa_original.py`).
- **Hankel-DMD fit.** `krylov/koopman_delay.py:fit_koopman_delay` with
  `rows_per_traj` uses only pairs `(z_t, z_{t+1})` within one trajectory
  (Figs. 5 and 7).
- **Comparison and reference matrices (Appendix D).** Every distance
  matrix is computed entry by entry for all ordered pairs,
  `M[i, j] = d(K_i, K_j')`; CSA is not symmetric in its arguments and the
  comparison matrices are not symmetric, so no entry is filled in by
  mirroring and no triangle is taken. nRMSE (residual of the best affine
  fit `D ≈ aB + c`, normalised by the standard deviation of `D`) and
  Pearson correlation always use **all N² entries** of `D` and `B`,
  including the diagonal, whose entries compare each system with its own
  conjugate or re-represented copy (`B_ii = 0`). References:
  - state-space conjugacy (Figs. 1, 2, 9): `D = d(K_i^orig, K_j^trans)`,
    `B = ½ [d(K_i^orig, K_j^orig) + d(K_i^trans, K_j^trans)]`
    (symmetrized, so neither coordinate system is preferred);
  - cross-dictionary (Fig. 3): `D = d(K_i^Fourier, K_j^Legendre)`,
    `B = ½ [d(K_i^F, K_j^F) + d(K_i^L, K_j^L)]`
    (symmetrized, so neither dictionary is preferred);
  - basis sweep (Fig. 4): `D = d(K_i^Fourier, K_j^(t))`,
    `B = d(K_i^Fourier, K_j^Fourier)` (fixed Fourier endpoint, so every
    point of the sweep is scored against the same reference).
- **Distances reported in the figures.** All EDMD figures use the raw
  Frobenius DSA distance and the `‖P_θ K₁ − K₂ P_θ‖_F / ‖P_θ‖_F` CSA
  distance. The Krylov plots divide each pair's DSA distance by `√r'`,
  where `r' = max(r'_f, r'_g)` is the size of the zero-padded matrices DSA
  compares (saved as `dsa_dim_conj` in the Fig. 5 result files).
- **Determinism.** All scripts seed their random number generators
  (`SEED = 42`, with offsets per system, per θ or per replicate where
  multiple seeds are needed). The exact numerical values in the saved
  arrays are reproducible up to BLAS-level nondeterminism.
