import os, sys, time
from dataclasses import replace
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from maps import generate_time_series
from krylov_subspace import build_delay_matrix_multi, svd_truncate
from koopman_delay import fit_koopman_delay
from dsa_original import compute_dsa_distance
from csa_krylov import compute_csa_krylov_distance


# ═══════════════════════════════════════════════════════════════════
#  Smooth bijection family
# ═══════════════════════════════════════════════════════════════════

def linear_map(y, r):
    return 0.5 + r * (np.asarray(y, dtype=float) - 0.5)


def h_smooth(x, a, n):
    """h_{a,n}; use n=0 as identity baseline."""
    x = np.asarray(x, dtype=float)
    n = int(round(n))
    if n == 0:
        return x
    return x - (a / (2.0 * np.pi * n)) * np.sin(2.0 * np.pi * n * (x - 0.5))


def h_smooth_deriv(x, a, n):
    x = np.asarray(x, dtype=float)
    n = int(round(n))
    if n == 0:
        return np.ones_like(x)
    return 1.0 - a * np.cos(2.0 * np.pi * n * (x - 0.5))


def h_smooth_inv(z, a, n, tol=1e-13, maxiter=80):
    z = np.asarray(z, dtype=float)
    n = int(round(n))
    if n == 0:
        return z

    z_clip = np.clip(z, 1e-12, 1.0 - 1e-12)
    x = z_clip.copy()
    for _ in range(maxiter):
        hx = x - (a / (2.0 * np.pi * n)) * np.sin(
            2.0 * np.pi * n * (x - 0.5)
        )
        hpx = 1.0 - a * np.cos(2.0 * np.pi * n * (x - 0.5))
        hpx_safe = np.where(
            np.abs(hpx) < 1e-6,
            1e-6 * np.where(hpx >= 0, 1.0, -1.0),
            hpx,
        )
        dx = (hx - z_clip) / hpx_safe
        x = np.clip(x - dx, 1e-12, 1.0 - 1e-12)
        if np.max(np.abs(dx)) < tol:
            break
    return x


def make_g_smooth(a_val, n_int):
    def g(x, r):
        hx = h_smooth(x, a_val, n_int)
        return h_smooth_inv(0.5 + r * (hx - 0.5), a_val, n_int)
    return g


def h_smooth_family(n_int):
    """Returns a 1-parameter (in a) family for CCD with n fixed."""
    def family(x, params):
        (a,) = params
        return h_smooth(x, a, n_int)
    return family


def make_composite_grid(n_uniform=5000, n_dense=3000, center=0.5,
                        width=0.15, margin=0.005):
    uniform = np.linspace(margin, 1.0 - margin, n_uniform)
    dense = np.linspace(center - width, center + width, n_dense)
    return np.unique(np.sort(np.concatenate([uniform, dense])))


# ═══════════════════════════════════════════════════════════════════
#  Configuration
# ═══════════════════════════════════════════════════════════════════

SEED       = 42
N_SERIES   = 50
DELAY_DIM  = 100
TS_LENGTH  = 150
RATES      = [0.5, 0.8]
REG, REG_P = 1e-6, 1e-8
ROWS_PER_TRAJ = TS_LENGTH - DELAY_DIM + 1   # rows per trajectory in H
TAU_RANK   = 1e-8   # keep SVD directions with sigma_k / sigma_1 > TAU_RANK

# Rank sweep
SVD_RANKS  = [5, 10, 20, 40,70, 80, 99]
A_REF      = 0.5
N_REF      = 4

# n sweep: vary n at fixed a
N_VALUES_SWEEP = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
RANK_VALUES    = [20]   # rank of Fig. 5b
A_FREQ         = 0.8

# A sweep: vary a at fixed n
A_FREQS_SWEEP  = np.linspace(0.0, 0.95, 10)
N_FOR_A_SWEEP  = 4
RANK_VALUES_A  = [20]

# CCD: outer loop over integer n; inner 1-D search over a
N_VALUES_CCD = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]   # n = 0: identity
A_GRID_1D    = np.linspace(0.0, 0.95, 19)
N_REFINE     = 30
X_COMPOSITE  = make_composite_grid()

DIR      = os.path.join(_HERE, "Results")
PLOT_DIR = os.path.join(_HERE, "plots")
os.makedirs(DIR, exist_ok=True)
os.makedirs(PLOT_DIR, exist_ok=True)


# ═══════════════════════════════════════════════════════════════════
#  System and pair construction
# ═══════════════════════════════════════════════════════════════════

CONJ_PAIRS = [(0, 2), (1, 3)]


def build_systems(a, n_int):
    g = make_g_smooth(a, int(n_int))
    return [
        ("lin(r=0.5)",      linear_map, 0.5),
        ("lin(r=0.8)",      linear_map, 0.8),
        (f"smooth(a={a:.2f},n={int(n_int)})(r=0.5)", g, 0.5),
        (f"smooth(a={a:.2f},n={int(n_int)})(r=0.8)", g, 0.8),
    ]


def build_data(systems, seed=SEED):
    rng = np.random.default_rng(seed)
    H = {}
    for i, (label, mf, p) in enumerate(systems):
        trajs = [generate_time_series(mf, p, rng.uniform(0.01, 0.99),
                                       TS_LENGTH)
                 for _ in range(N_SERIES)]
        H[i] = build_delay_matrix_multi(trajs, DELAY_DIM)
    return H


def fit_at_rank(H, rank):
    Ks, infos = {}, {}
    for i in H:
        S = svd_truncate(H[i], rank=rank).S
        r = int(min(rank, np.sum(S > TAU_RANK * S[0])))
        info = svd_truncate(H[i], rank=r)
        info = replace(info, V_r=info.V_r / info.S[:r])
        Ks[i] = fit_koopman_delay(H[i], info, reg=REG,
                                  rows_per_traj=ROWS_PER_TRAJ)
        infos[i] = info
    return Ks, infos


def pair_distance(Ks, infos, systems, i, j):
    _, mfi, pi = systems[i]
    _, mfj, pj = systems[j]
    d_dsa = compute_dsa_distance(Ks[i], Ks[j])
    dsa_dim = max(Ks[i].shape[0], Ks[j].shape[0])

    best_d = np.inf
    best_a = 0.0
    best_n = N_VALUES_CCD[0]
    for n_int in N_VALUES_CCD:
        family = h_smooth_family(n_int)
        d_ccd, p_opt = compute_csa_krylov_distance(
            Ks[j], Ks[i], mfj, pj, mfi, pi,
            infos[j], infos[i],
            family, [A_GRID_1D],
            n_refine=N_REFINE, reg=REG_P, x_grid=X_COMPOSITE)
        if d_ccd < best_d:
            best_d = d_ccd
            best_a = p_opt[0]
            best_n = n_int
    return d_dsa, best_d, (best_a, best_n), dsa_dim


def evaluate(systems, H, rank, label_prefix=""):
    Ks, infos = fit_at_rank(H, rank)
    dsa_conj, ccd_conj, p_conj, dim_conj = [], [], [], []
    for (i, j) in CONJ_PAIRS:
        t0 = time.time()
        d_dsa, d_ccd, p, dim = pair_distance(Ks, infos, systems, i, j)
        dsa_conj.append(d_dsa); ccd_conj.append(d_ccd); p_conj.append(p)
        dim_conj.append(dim)
        print(f"    {label_prefix}conj ({i},{j}): "
              f"DSA={d_dsa:7.3f}  CCD={d_ccd:7.4f}  "
              f"a*={p[0]:.3f} n*={p[1]}  r'={dim}  "
              f"({time.time()-t0:.1f}s)", flush=True)
    return (np.array(dsa_conj),
            np.array(ccd_conj),
            np.array([(float(a), int(n)) for a, n in p_conj]),
            np.array(dim_conj))


# ═══════════════════════════════════════════════════════════════════
#  Sweeps
# ═══════════════════════════════════════════════════════════════════

def run_rank_sweep():
    print(f"\n{'='*70}", flush=True)
    print(f"SMOOTH RANK SWEEP at (a*, n*) = ({A_REF}, {N_REF})", flush=True)
    print(f"{'='*70}", flush=True)
    systems = build_systems(A_REF, N_REF)
    H = build_data(systems, seed=SEED)
    nR = len(SVD_RANKS)
    dsa_c = np.empty((nR, len(CONJ_PAIRS)))
    ccd_c = np.empty((nR, len(CONJ_PAIRS)))
    p_c   = np.empty((nR, len(CONJ_PAIRS), 2))
    dim_c = np.empty((nR, len(CONJ_PAIRS)), dtype=int)
    t_start = time.time()
    for ri, rank in enumerate(SVD_RANKS):
        t0 = time.time()
        print(f"\n  rank={rank}", flush=True)
        dsa_c[ri], ccd_c[ri], p_c[ri], dim_c[ri] = \
            evaluate(systems, H, rank, label_prefix=f"r{rank} ")
        print(f"  --> rank={rank}: "
              f"DSA conj={dsa_c[ri].mean():.3f}  |  "
              f"CCD conj={ccd_c[ri].mean():.4f}  "
              f"[{time.time()-t0:.0f}s]", flush=True)
    out = os.path.join(DIR, "section3_smooth_rank_sweep.npz")
    np.savez(out,
             ranks=np.asarray(SVD_RANKS, dtype=int),
             a_ref=A_REF, n_ref=N_REF,
             dsa_conj=dsa_c,
             ccd_conj=ccd_c,
             params_conj=p_c,
             dsa_dim_conj=dim_c)
    print(f"\nSaved {out}.  Total: {time.time()-t_start:.0f}s", flush=True)


def run_n_sweep():
    print(f"\n{'='*70}", flush=True)
    print(f"SMOOTH n SWEEP at a* = {A_FREQ}, ranks {RANK_VALUES}", flush=True)
    print(f"{'='*70}", flush=True)
    nN = len(N_VALUES_SWEEP); nR = len(RANK_VALUES)
    dsa_c = np.empty((nR, nN, len(CONJ_PAIRS)))
    ccd_c = np.empty((nR, nN, len(CONJ_PAIRS)))
    p_c   = np.empty((nR, nN, len(CONJ_PAIRS), 2))
    dim_c = np.empty((nR, nN, len(CONJ_PAIRS)), dtype=int)
    t_start = time.time()
    for ni, n_true in enumerate(N_VALUES_SWEEP):
        print(f"\n*** n = {n_true} ***", flush=True)
        systems = build_systems(A_FREQ, n_true)
        H = build_data(systems, seed=SEED + ni)
        for ri, rank in enumerate(RANK_VALUES):
            t0 = time.time()
            print(f"  rank={rank}", flush=True)
            dsa_c[ri,ni], ccd_c[ri,ni], p_c[ri,ni], dim_c[ri,ni] = \
                evaluate(systems, H, rank,
                         label_prefix=f"n{n_true}r{rank} ")
            print(f"  --> n={n_true} r={rank}: "
                  f"DSA conj={dsa_c[ri,ni].mean():.3f}  |  "
                  f"CCD conj={ccd_c[ri,ni].mean():.4f}  "
                  f"[{time.time()-t0:.0f}s]", flush=True)
    out = os.path.join(DIR, "section3_smooth_n_sweep.npz")
    np.savez(out,
             n_values=np.asarray(N_VALUES_SWEEP, dtype=int),
             ranks=np.asarray(RANK_VALUES, dtype=int),
             a_freq=A_FREQ,
             dsa_conj=dsa_c,
             ccd_conj=ccd_c,
             params_conj=p_c,
             dsa_dim_conj=dim_c)
    print(f"\nSaved {out}.  Total: {time.time()-t_start:.0f}s", flush=True)



def run_a_freq_sweep():
    print(f"\n{'='*70}", flush=True)
    print(f"SMOOTH A_FREQ SWEEP at n* = {N_FOR_A_SWEEP}, ranks {RANK_VALUES_A}", flush=True)
    print(f"{'='*70}", flush=True)
    nA = len(A_FREQS_SWEEP); nR = len(RANK_VALUES_A)
    dsa_c = np.empty((nR, nA, len(CONJ_PAIRS)))
    ccd_c = np.empty((nR, nA, len(CONJ_PAIRS)))
    p_c   = np.empty((nR, nA, len(CONJ_PAIRS), 2))
    dim_c = np.empty((nR, nA, len(CONJ_PAIRS)), dtype=int)
    t_start = time.time()
    for ai, a_true in enumerate(A_FREQS_SWEEP):
        a_true = float(a_true)
        print(f"\n*** A_FREQ = {a_true:.3f} ***", flush=True)
        systems = build_systems(a_true, N_FOR_A_SWEEP)
        H = build_data(systems, seed=SEED + ai)
        for ri, rank in enumerate(RANK_VALUES_A):
            t0 = time.time()
            print(f"  rank={rank}", flush=True)
            dsa_c[ri, ai], ccd_c[ri, ai], p_c[ri, ai], dim_c[ri, ai] = \
                evaluate(systems, H, rank,
                         label_prefix=f"a{a_true:.3f}n{N_FOR_A_SWEEP}r{rank} ")
            print(f"  --> A_FREQ={a_true:.3f} n={N_FOR_A_SWEEP} r={rank}: "
                  f"DSA conj={dsa_c[ri, ai].mean():.3f}  |  "
                  f"CCD conj={ccd_c[ri, ai].mean():.4f}  "
                  f"[{time.time()-t0:.0f}s]", flush=True)
    out = os.path.join(DIR, "section3_smooth_a_freq_sweep.npz")
    np.savez(out,
             a_freqs=np.asarray(A_FREQS_SWEEP, dtype=float),
             n_ref=N_FOR_A_SWEEP,
             ranks=np.asarray(RANK_VALUES_A, dtype=int),
             dsa_conj=dsa_c,
             ccd_conj=ccd_c,
             params_conj=p_c,
             dsa_dim_conj=dim_c)
    print(f"\nSaved {out}.  Total: {time.time()-t_start:.0f}s", flush=True)

def main():
    # optional argument: run only one sweep ("rank", "n" or "a")
    which = sys.argv[1:] or ["rank", "n", "a"]
    t0 = time.time()
    if "rank" in which:
        run_rank_sweep()
    if "n" in which:
        run_n_sweep()
    if "a" in which:
        run_a_freq_sweep()
    print(f"\nGRAND TOTAL: {time.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
